import "./paraSection.css";

export default function ParaSection({ para }) {
  return <p className="section-para">{para}</p>;
}
